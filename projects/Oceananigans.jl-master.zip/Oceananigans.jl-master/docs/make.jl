using Documenter
using Oceananigans, Oceananigans.Operators

push!(LOAD_PATH,"../src/")

makedocs(sitename="Oceananigans.jl")
