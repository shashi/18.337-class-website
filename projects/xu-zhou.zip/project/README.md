This directory organizes as follows:

- analyze.ipynb contains function that are useful in this project or more general purpose. It includes 
  1. @analyzeMyFloat: count the number of arithmetic operations of a user-defind type MyFloat64;
  2. @analyze: count the number of arithmetic operations of any types;
  3. estimateComplexity: estimate the time complexity of a single argument function.

- analyzeExamples.ipynb contains example usage of functions defined in analyze.ipynb. 

- Identities.ipynb is used to analyze and help better understand sub-cubic matrix multiplications. It includes
  1. a Julia-Style implementation of Strassen's Algorithm (with specified input data structure);
  2. comparison between Strassen's Algorithm and Naive implementation of matrix multiplication;
  3. an example of matrix multiplication approximation algorithm based on Schnohage's Identity, which can be used to give rise to a faster matrix multiplication.

- matrix.ipynb is used to compare Strassen's Algorithm and naive matrix multiplication under C-Style implementations.