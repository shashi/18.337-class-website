""" 
The Stochastic model type includes all possible four input-outout types 
of general Bayesian Inverse problems. Here we are going to consider the 
following setting of inverse problem:

y = F(θ) + ξ

θ ~ Parameters of size dₚ
y ~ Measurements (known data) of size dₘ
ξ ~ Measurement noise
F ~ Forward model

"""

"""
StochasticModels type is the type that every model should be based on.
Any new model will inherit from this type and would typically have the 
following parameters

dₚ ~ dimension of parameter space 
dₘ ~ dimension of model space
μ₀ ~ Prior mean
Σ₀ ~ Prior covariance matrix
μₘ ~ Likelihood mean
Σₘ ~ Likelihood covariance matrix / noise
"""
abstract type StochasticModel end
logₚ(M::StochasticModel, θ::Array{Float64,2}) = sum(-.5*(θ .- M.μₚ).^2 / M.Σₚ, dims=1) # ~ (1,n)
logₗ(M::StochasticModel, θ::Array{Float64,2}, F::Array{Float64,2}) = -.5*(F .- M.μₘ).^2 / M.Σₘ # ~(1,n)
logπ(M::StochasticModel, θ::Array{Float64,2}, F::Array{Float64,2}) = logₚ(M, θ) + logₗ(M,θ,F) # ~ (1,n)
∇logₚ(M::StochasticModel, θ::Array{Float64,2}) = -(θ .- M.μₚ)/M.Σₚ # ~ (dₚ,n)
∇logₗ(M::StochasticModel, θ::Array{Float64,2}, F::Array{Float64,2}, J::Array{Float64,2}) = -J.*(F.-M.μₘ)/M.Σₘ # ~ (dₚ,n)
∇logπ(M::StochasticModel, θ::Array{Float64,2}, F::Array{Float64,2}, J::Array{Float64,2}) = ∇logₚ(M, θ) + ∇logₗ(M, θ, F, J) # ~ (dₚ,n)
Hlogπ(M::StochasticModel, θ::Array{Float64,2}, J::Array{Float64,2}) = [J[:,i]*J[:,i]'/M.Σₘ + Diagonal([1.0,1.0])/M.Σₚ for i in 1:size(θ,2)]
function plot_p(M::StochasticModel,  R::Array{Float64,1}=[-5.,5.], npts::Int64=100)
    I = range(R[1], stop=R[2], length=npts)
    Z = zeros(npts,npts)
    for i in 1:npts
        for j in 1:npts
            pt = Matrix( [I[i] I[j]]' )
            F = Fw(M, pt)
            Z[j,i] = exp(logπ(M, pt, F)[1])
        end
    end
    return I,Z
end

function plot(M::StochasticModel,  R::Array{Float64,1}=[-5.,5.], npts::Int64=100)
    I = range(R[1], stop=R[2], length=npts)
    Z = zeros(npts,npts)
    for i in 1:npts
        for j in 1:npts
            pt = Matrix( [I[i] I[j]]' )
            F = Fw(M, pt)
            Z[j,i] = exp(logπ(M, pt, F)[1])
        end
    end
    Plots.contour(I,I,Z, fill=true, color=:heat)
end

"""
GAUSS2 model:
The forward mapping is just a linear transformation of the pararameters.

    Fw(θ) = α'θ

"""
@with_kw struct GAUSS2 <: StochasticModel
    dₚ::Int64 = 2
    dₘ::Int64 = 1
    μₚ::Array{Float64,1}
    Σₚ::Float64
    μₘ::Float64 
    Σₘ::Float64 
    α::Array{Float64,1}
end

" Forward mapping and Jacobian"
Fw(M::GAUSS2, θ::Array{Float64,2}) = Matrix(M.α'*θ) # ~ (1,n)
JF(M::GAUSS2, θ::Array{Float64,2}) = repeat(M.α, 1, size(θ,2)) # ~ (dₚ, n)

"""
BANANA2 model:
The forward mapping takes the form of a Rosenbrock function

    Fw(θ) = log((1-θ₂)² + 100(θ₂-θ₁²)²)

"""
@with_kw struct BANANA2 <: StochasticModel
    dₚ::Int64 = 2
    dₘ::Int64 = 1
    μₚ::Array{Float64,1}
    Σₚ::Float64 
    μₘ::Float64 
    Σₘ::Float64 
end

" Forward mapping and Jacobian"
Fw(M::BANANA2, θ::Array{Float64,2}) = Matrix([log.((1.0 .- θ[2,:]).^2 + 100*(θ[2,:] - θ[1,:].^2).^2);]') # ~ (1,n)
JF(M::BANANA2, θ::Array{Float64,2}) =  hcat(-400.0*θ[1,:].*(θ[2,:]-θ[1,:].^2), 2*(θ[2,:].-1.0)+200*(θ[2,:] - θ[1,:].^2))' ./ ((1.0 .- θ[2,:]).^2 + 100*(θ[2,:] - θ[1,:].^2).^2)'  # ~ (dₚ,n)

"""
Kernel type used to contain all the kernel operations.
The two main kernel implementations are the isotropic Gaussian (isoRBF)
and the General Gaussian (genRBF).
"""
abstract type kernel end

"""
Isotropic Gaussian, with variance h:

    K(x,y) = exp(-||x-y||²/2h)

"""
struct isoRBF <: kernel
    h::Float64
end

"Single/Two-sample, kernel/Derivative, in/out-place.
Input: Estimation sample X~(dₚ,n), new sample Y~(dₚ,m)
Return: K_[i,j]=K(xᵢ,yⱼ) ~(n,m), ∇K_[:,j]=Σᵢ∇ₓK(xᵢ,yⱼ)~(dₚ,m)"
function Kxy(K::isoRBF, J::Array{Float64,2}, X::Array{Float64,2}, Y::Array{Float64,2})
    (dₚ,n) = size(X)
    m = size(Y, 2)
    K_ = fill(0.0, n, m)
    ∇K_ = fill(0.0, dₚ, m)
    for kk in 1:m
        Dxy = X .- Y[:,kk]
        K_[:,kk] = exp.( (-.5/K.h) * sum(Dxy.^2, dims=1) )'
        ∇K_[:,kk] = -(1. /K.h) * Dxy * K_[:,kk]
    end
    return K_, ∇K_
end
function Kxy!(K::isoRBF, J::Array{Float64,2}, X::Array{Float64,2}, Y::Array{Float64,2}, K_::Array{Float64,2}, ∇K_::Array{Float64,2})
    m = size(Y, 2)
    for kk in 1:m
        Dxy = X .- Y[:,kk]
        K_[:,kk] = exp.( (-.5/h) * sum(Dxy.^2, dims=1) )'
        ∇K_[:,kk] = (1. /h) * Dxy * K_[:,kk]
    end
end

"""
General Gaussian, with precision matrix J:

    K(x,y) = exp(-(x-y)'J(x-y))

"""
struct genRBF <: kernel
#     J::Array{Float64,2}
end

"Single/Two-sample, kernel/Derivative, in/out-place.
Input: Estimation sample X~(dₚ,n), new sample Y~(dₚ,m), K.J ~ (d,d) Precision matrix
Return: K_[i,j]=K(xᵢ,yⱼ) ~(n,m), ∇K_[:,j]=Σᵢ∇ₓK(xᵢ,yⱼ)~(dₚ,m)"
function Kxy(K::genRBF, J::Array{Float64,2}, X::Array{Float64,2}, Y::Array{Float64,2}) 
    (dₚ,n) = size(X)
    m = size(Y, 2)
    K_ = fill(0.0, n, m)
    ∇K_ = fill(0.0, dₚ, m)
    for kk in 1:m
        Dxy = X .- Y[:,kk]
        MDxy = J * Dxy
        K_[:,kk] = exp.( -sum(Dxy .* MDxy, dims=1) )'
        ∇K_[:,kk] = -MDxy * K_[:,kk]
    end
    return K_, ∇K_
end
function Kxy!(K::genRBF, J::Array{Float64,2}, X::Array{Float64,2}, Y::Array{Float64,2}, K_::Array{Float64,2}, ∇K_::Array{Float64,2}) 
    m = size(Y, 2)
    for kk in 1:m
        Dxy = X .- Y[:,kk]
        MDxy = J * Dxy
        K_[:,kk] = exp.( -sum(Dxy .* MDxy, dims=1) )'
        ∇K_[:,kk] = -MDxy * K_[:,kk]
    end
end

"""
Optimizer Type for first order methods, see:\n
ConstantRate, Momentum, AdaGrad, RMSprop
"""
abstract type FirstOrderOptimizer end
"ConstantRate Optimize. \n\n 
Inputs: \n\n
\t η::Float64 ~ Learning Rate "
struct ConstantRate <: FirstOrderOptimizer
    η::Float64
end
struct Momentum <: FirstOrderOptimizer
    η::Float64
    γ::Float64
end
struct AdaGrad <: FirstOrderOptimizer
    η::Float64 
    ϵ::Float64
end
struct RMSprop <: FirstOrderOptimizer
    η::Float64
    γ::Float64
    ϵ::Float64
end

"Optimizing functions declarations"
function Optimize!(rule::ConstantRate, Δθ::Array{Float64,2}, ∇::Array{Float64,2}, past::Array{Float64,2})
    Δθ .= -rule.η * ∇
end
function Optimize!(rule::Momentum, Δθ::Array{Float64,2}, ∇::Array{Float64,2}, past::Array{Float64,2})
    v = rule.γ * past + rule.η * ∇
    Δθ .= -v
    past .= v
end
function Optimize!(rule::AdaGrad, Δθ::Array{Float64,2}, ∇::Array{Float64,2}, past::Array{Float64,2})
    past .+= ∇.^2
    Δθ .= - (rule.η ./ sqrt.(past .+ rule.ϵ)) .* ∇
end
function Optimize!(rule::RMSprop, Δθ::Array{Float64,2}, ∇::Array{Float64,2}, past::Array{Float64,2})
    past .= rule.γ * past + (1.0-rule.γ) * ∇.^2
    Δθ .= - (rule.η ./ sqrt.(past .+ rule.ϵ)) .* ∇
end


"""
Optimizer Type for second order methods
"""
abstract type SecondOrderOptimizer end
struct ConstantRates <: SecondOrderOptimizer
   ϵ::Float64 
end
struct stabilizedRate <: SecondOrderOptimizer
    ϵ::Float64
    sup::Float64
    inf::Float64
end
"Optimizing functions declarations"
function Optimize!(rule::ConstantRates, α::Array{Float64,2}, ∇::Array{Float64,1}, H::Array{Float64,2}, past::Array{Float64,1})
    return rule.ϵ * H\∇
#     TODO Has bugs!
end


""" 
Two types of Stein Variate descente algorithms
"""
abstract type SteinVariate end
struct SVGD <: SteinVariate
    niter::Int64
    npersists::Int64
    rule::FirstOrderOptimizer
end

struct SVN <: SteinVariate
    niter::Int64
    npersists::Int64
    rule::SecondOrderOptimizer
end

"Transport functions for SVDG and SVN"
function transport!(θ::Array{Float64,2}, M::StochasticModel, K::kernel, SV::SVGD)
    (dₚ,n) = size(θ)
    # Persistence
    persist_each = ceil(SV.niter/SV.npersists)
    history = zeros(size(θ)..., SV.npersists+1)
    count = 1
    history[:,:,count] = θ
    
    # In-place evaluation of step and past info for momentum algorithms
    Δθ = zeros(size(θ))
    past = zeros(size(θ))
    for i in 1:SV.niter
        F = Fw(M, θ)
        J = JF(M, θ)
        H = Hlogπ(M,θ,J)
        K_, ∇K_ = Kxy(K,mean(H),θ,θ)
        Optimize!(SV.rule, Δθ, -(1.0/n)*(∇logπ(M,θ,F,J)*K_ + ∇K_), past)
        θ .+= Δθ
        
        # Persistence
        if i % persist_each == 0
            count += 1
            history[:,:,count] = copy(θ)
        end
    end
    return history
end

function transport!(θ::Array{Float64,2}, M::StochasticModel, K::kernel, SV::SVN)
    (dₚ,n) = size(θ)
    # Persistence
    persist_each = ceil(SV.niter/SV.npersists)
    history = zeros(size(θ)..., SV.npersists+1)
    count = 1
    history[:,:,count] = θ
    
    α = zeros(dₚ,n)
    ϵ = zeros(1,n)
    for i in 1:SV.niter
        F = Fw(M, θ)
        J = JF(M, θ)
        H = Hlogπ(M,θ,J)
        K_, ∇K_ = Kxy(K,mean(H),θ,θ)
        ∇ = -(1.0/n)*(∇logπ(M,θ,F,J)*K_ + ∇K_)
        for ss in 1:n
            α[:,ss] =  pinv(-mean(H[ii] * K_[ss,ii].^2 for ii in 1:n) + (∇K_[:,ss] * ∇K_[:,ss]')/n) * ∇[:,ss]
        end
        θ .+= α #* K_ 
        
        # The code from Marzouk et al does two big caveats that unclear mathematically and otherwise:
        # Caveat 1: E ∇k ∇k' = E∇k E∇k'
        # Caveat 2: the code is assuming that Kₘ(xᵢ,xⱼ) = δᵢⱼ
        
        # Persistence
        if i % persist_each == 0
            count += 1
            history[:,:,count] = copy(θ)
        end
    end
    return history
end