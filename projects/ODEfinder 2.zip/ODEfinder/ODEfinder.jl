#Load the necessary packages
using LinearAlgebra, FFTW, ApproxFun, SpecialFunctions, Statistics

# Loaf the three main packages
include("src/dynamics_learning.jl")
include("src/equi_data.jl")
include("src/wavelet_smooth.jl")
