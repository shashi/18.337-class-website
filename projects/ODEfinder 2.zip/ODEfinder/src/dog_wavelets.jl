# This file defines the the basic functions used for the Derivative of Gaussian wavelets. These wavelets can then be used in the
# continuous wavelet transform function to decompose signals

# Calculate the value of the dog_wavelet in position space using Hermite polynomial recursion

function dog_wavelet_rec(x::Array{T,S},m::Int) where {T <: Real,S}
    return - prob_hermite(x,m)/sqrt(gamma(m+0.5))
end

# Recursion for probabalists hermite functions
function prob_hermite(x::Array{T,N},n::Int) where {T <: Real,N}
    hold = exp.(-x.^2/2); hold[abs.(hold) .< eps()] .= 0.0
    hnew = x.*exp.(-x.^2/2); hnew[abs.(hnew) .< eps()] .= 0.0
    if n == 0
        return hold
    elseif n==1
        return hnew
    else
        for m = 1:n-1
            h = (x.*hnew - m*hold)
            h[abs.(h) .< eps()] .= 0.0
            hold = hnew
            hnew = h
        end
        return hnew
    end
end

# Calculate the wavelet in position space using cont_fft of its fourier transform
function dog_wavelet_fft(x::Array{Real,N},m::Int) where N
   f̂(w) = - sqrt(2π/gamma(m + 0.5))*(-im*2π*w).^m.*exp.(-2π^2*w.^2)
   return cont_ifft(f̂,x)
end

function dog_wavelet_fft(x,m::Int,iP) where N
   f̂(w) = - sqrt(2π/gamma(m + 0.5))*(-im*2π*w).^m.*exp.(-2π^2*w.^2)
   return cont_ifft(f̂,x,iP,1)
end


# We see that at m = 17 the pre_planned fft and the recursion are equal to each other in time.
    #x = -10:0.1:10; P = plan_fft(x); iP = inv(P)
    #@time dog_wavelet_fft(x,18,iP)
    #@time dog_wavelet_rec(x,18)
abstract type RealContWave end

struct dog_wavelet <: RealContWave
    m::Int
    L::Float64 #8.7
end

dog_wavelet(m::Int) = dog_wavelet(m,8.7)

function (f::dog_wavelet)(x::Array{T}; ft=false) where {T <: Real}#Calculate the value of the wavelet
    if ft
        return -sqrt(2π/gamma(f.m + 0.5))*(-im*2π*x).^(f.m).*exp.(-2π^2*x.^2)
    elseif f.m != 2
        return - prob_hermite(x,f.m)/sqrt(gamma(f.m+0.5))
    else
        return (x.^2 .- 1).*exp.(-x.^2/2)
    end
end
