# Define the standard prox funs

function proxl1!(η::T,y::Array) where T <: Real
    y[abs.(y) .<= η].=0
    gind = y .> η
    lind = y .< -η
    y[gind] .= y[gind].-η
    y[lind] .= y[lind].+η
    y
end

function proxl0!(η::T,y::Array) where T <: Real
    y[abs.(y) .<= sqrt(2η)] .= 0
    y
end

function proxl2_2!(η::T,y::Array) where T <: Real
    y .= y/(1 + η)
end

function proxl2!(η::T,y::Array) where T <: Real
    y2 = norm(y)
    if y2 > η
        y .= (y2 - η)*y/y2
    else
        y.=0
    end
end

function SR3(κ::T , A::Array , b::Array, λ::S; w::Array = rand(size(A,2),size(b,2)) , itr::Int = 10, R = proxl1!) where {T,S <: Real}
    η = λ/κ
    κinv = 1/κ
    H = A'A + κ*I
    Hinv = inv(H)
    Ab = Hinv*A'*b
    F = vcat(κ*A*Hinv, sqrt(κ)*(I - κ*Hinv))
    g = vcat(b - A*Ab, sqrt(κ)*Ab)
    for k = 1:itr
        w = R(η, w - κinv*F'*(F*w - g))
    end
    return w
end
