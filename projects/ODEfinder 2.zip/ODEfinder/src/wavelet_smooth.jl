include("dog_wavelets.jl")
function cwt(x::Array{S,1}, f::Array{S,1},ψ::N,T::Float64;dj= 0.25) where{S<:Real,N<:RealContWave}
    @assert length(x) == length(f)
    n = length(f);
    # Choice of scales
    J = ceil(log(2,n/2)/dj)
    avec = T*2 .^(dj*(0:1:J))
    aL = ceil(Int,maximum(avec)*ψ.L/T)
    ftilde = vcat(f,zeros(2aL,1));

    # Pre plan the fft which will be used for each a -> speed
    P = plan_fft(ftilde)
    iP = inv(P)

    # Calculate the transform at each scales, real since the WT of a real wavelet and real signal is real
    @time psi_In = (aL*T .- T*collect(0:1:2aL))./avec'
    @time psiMat = ψ(psi_In)
    @time psiMat = psiMat./avec'
    @time htilde = vcat( psiMat ,zeros(n-1,size(avec,1)))
    @time cwtvec = real.(T*ifft(fft(ftilde).*fft(htilde,1),1)[aL+1:aL+n,:])

    return Array(cwtvec'), avec
end

function icwt(x::Array,cwt_arrayKr::Array, avecKr::Array,ψ::N ,sig::Array; dj=0.25) where {N <: RealContWave}
    expmat = zeros(Complex{Float64},length(avec),length(x)) #TODO: it is a striped
    dj2 = (2^(-dj))
    dj2vec = zeros(length(avec))
    for i = 1:length(avec)
        expmat[i,:] = exp.(im*x'/avecKr[i])
        dj2vec[i] = dj2^(i-1)
    end
    sum1 = sum(cwt_arrayKr./expmat,dims=2)
    sum2 = sum(sum1.*expmat.*dj2vec,dims=1)
    recon = ((-1).^ψ.m)*real.(((1/dj2 -1)/(ψ([1/(2*pi)]; ft=true)[1]*(2*pi)))*reshape(sum2,length(x)))
    shift = mean(sig) - mean(-0.21*2.6*pi*recon)
    return -0.21*2.6*pi*recon .+shift
end
