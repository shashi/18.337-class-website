#using PyPlot, ApproxFun

function w(x,k::Int,d::Int)
    @assert 0 ≤ k ≤ length(x) "k must be less than n"
    jk = maximum([(k-d+1),1]):1:minimum([k+1,length(x)-d])
    wk = 0
    for i ∈ jk
        prod = 1
        for j = i:i+d;
            if j/(k+1) == 1
                continue
            end
        prod *= 1/(x[k+1] - x[j])
    end
        wk += (-1)^(i+1)*prod
    end
    return wk
end
w(x::Array,k::Array{Int64,1},d::Int) = broadcast(k2 -> w(x,k2,d),k)

function r(y::T,x,w,fvec;d=2) where {T <: Number}
    if sum(y .≈ x) ≥ 1
        ind = findall(y .≈ x)
        println(ind[1][2])
        return fvec[:,ind[1][2]]
    else
        mid =sum((w.*fvec)./(y .- x),dims=d)/sum(w./(y .-x))
        return mid
    end
end
function r(y::Array{T,1},x,w,fvec) where {T <: Number}
    mat = zeros(size(fvec,1),size(y,1))
    for n = 1:1:size(y,1)
        rt = r(y[n],x,w,fvec)
        if typeof(rt) <: Number
            mat[:,n] = [r(y[n],x,w,fvec)]
        else
            mat[:,n] = r(y[n],x,w,fvec)
        end
    end
    return mat
end
#=
function r(y::Array{T,1},x,w,fvec) where {T <: Number}
    broadcast(k2 -> r(k2,x,w,fvec),y)
end
=#
function data(x::Array,vals::Array,S=Chebyshev(); order::Int = 3, numpoints::Int = length(x))
    if mod(numpoints,2) == 1
        numpoints = numpoints-1
    end
    P = points(S,numpoints)
    wc = w(x,collect(0:1:length(x)-1),order)
    rvec = r(P,x',wc',vals')
    rvec = reshape(rvec,length(P))
    return dataFun  = Fun(S,ApproxFun.transform(S,rvec))
end

# Functions for Lagrange Interpolation for comparison
function l(y,x,j) #Define the lagrange basis
     val = 1;
     for n = 1:length(x)
         if (j+1)/n == 1; continue; end;
         val *= (y - x[n])/(x[j+1] - x[n]);
     end
     return val
 end

l(y::Array,x,d::Int) = broadcast(k -> l(k,x,d),y)
L(x,x0,y) = y'*[l(x,x0,j) for j = 0:1:length(x0)-1] #Define the lagrange interpolant
L(x::Array, x0,y) =  broadcast(k -> L(k,x0,y),x)

function div_fun(x,h=1)
    div_vec = Float64[]
    for n = 1:minimum([2,length(x)])
        push!(div_vec,-25x[n]/12 + 4x[n+1] -3x[n+2] + 4x[n+3] - x[n+4]/4)
    end
    for n = 3:length(x)-3
        push!(div_vec, x[n-2]/12 -2*x[n-1]/3 + 2*x[n+1]/3 - x[n+2]/12)
    end
    for n = maximum([length(x)-2,minimum([2,length(x)].+1)]):length(x)
        push!(div_vec,25x[n]/12 - 4x[n-1] +3x[n-2] - 4x[n-3] + x[n-4]/4)
    end
    return div_vec/h
end
