# Two versions of makeθ - Julia's multiple dispatch figures out which version to use for
# ODE vs PDE.

# makeθ for ODE data => no partial derivatives

function makeθ(data::Array{T,N} ; poly_order::Int = 5, trig_order::Int = 5) where {T,N}
    dict = Dict(); ind = 1
    dict[ind] = "1"; ind += 1
    θ3 = data
    nv = size(data,2)
    if nv == 1
        dict[ind] = "x"; ind += 1
    elseif nv == 2
        dict[ind] = "x"; ind += 1
        dict[ind] = "y"; ind += 1
    elseif nv == 3
        dict[ind] = "x"; ind += 1
        dict[ind] = "y"; ind += 1
        dict[ind] = "z"; ind += 1
    else
        for n = 1:size(data,2)
            dict[ind] = "x$n"; ind += 1
        end
    end
    s = 1
    prev = data
    for n = 2:poly_order
        prev, ind, s = mult_fun!(prev,data,n, dict, ind,s)
        θ3 = hcat(θ3,prev)
    end
    θ3 = hcat(ones(size(data,1),1),θ3)
    if trig_order >= 1
    θ3 = hcat(θ3, sin.(data), cos.(data))
        for j = 1:nv
            dict[ind] = "sin("*dict[j+1]*")"; ind += 1
        end
        for j = 1:nv
            dict[ind] = "cos("*dict[j+1]*")"; ind += 1
        end
    end
    for i = 2:trig_order
        θ3 = hcat(θ3, sin.(i*data), cos.(i*data))
        for j = 1:nv
            dict[ind] = "sin($i"*dict[j+1]*")"; ind += 1
        end
        for j = 1:nv
            dict[ind] = "cos($i"*dict[j+1]*")"; ind += 1
        end
    end
    return θ3, dict
end

# makeθ for PDE data => partial derivatives
function makeθ(data::Array{T,N},data_deriv::Array; poly_order::Int = 5, trig_order::Int = 5) where {T,N}
    dict = Dict(); ind = 1
    dict[ind] = "1"; ind += 1
    θ3 = data
    nv = size(data,2)
    if nv == 1
        dict[ind] = "u"; ind += 1
    elseif nv == 2
        dict[ind] = "u"; ind += 1
        dict[ind] = "v"; ind += 1
    elseif nv == 3
        dict[ind] = "u"; ind += 1
        dict[ind] = "v"; ind += 1
        dict[ind] = "w"; ind += 1
    else
        for n = 1:size(data,2)
            dict[ind] = "u$n"; ind += 1
        end
    end
    s = 1
    prev = data
    for n = 2:poly_order
        prev, ind, s = mult_fun!(prev,data,n, dict, ind,s)
        θ3 = hcat(θ3,prev)
    end
    θ3 = hcat(ones(size(data,1),1),θ3)

    #Now append the derivatives
    nd = size(data_deriv,2)
    nold = size(θ3,2)
    for m = 1:nv
    for n = 1:Int(nd/nv)
        θ3 = hcat(θ3,θ3[:,1:nold].*data_deriv[:,m*n])
        for i = 1:nold
            dict[ind] = " "*dict[i]*dict[m+1]*"_"*"x"^n
            ind +=1
        end
    end
    end

    if trig_order >= 1
    θ3 = hcat(θ3, sin.(data), cos.(data))
        for j = 1:nv
            dict[ind] = "sin("*dict[j+1]*")"; ind += 1
        end
        for j = 1:nv
            dict[ind] = "cos("*dict[j+1]*")"; ind += 1
        end
    end
    for i = 2:trig_order
        θ3 = hcat(θ3, sin.(i*data), cos.(i*data))
        for j = 1:nv
            dict[ind] = "sin($i"*dict[j+1]*")"; ind += 1
        end
        for j = 1:nv
            dict[ind] = "cos($i"*dict[j+1]*")"; ind += 1
        end
    end
    return θ3, dict
end

# Helper functions for makeθ's recursion
function mult_fun(A::Array,B::Array,loop::Int)
    if loop == 1
        return B
    else
    len = size(B,2)
    out = A.*B[:,1]
    indvec = ind_vec_make(len,loop)
    for n = 2:len
        out = hcat(out, A[:,indvec[n]:end].*B[:,n])
    end
    return out
    end
end

function mult_fun!(A::Array,B::Array,loop::Int,dict::Dict{Any,Any}, ind::Int,s::Int)
    sold = size(A,2)
    if loop == 1
        return B
    else
    len = size(B,2)
    out = A.*B[:,1]
    for m = 1+s:size(A,2)+s
        dict[ind] = dict[2]*dict[m]
        ind += 1
    end
    indvec = ind_vec_make(len,loop)
    for n = 2:len
        out = hcat(out, A[:,indvec[n]:end].*B[:,n])
        for m = indvec[n]+s:size(A,2)+s
            dict[ind] = dict[n+1]*dict[m]
            ind += 1
        end
    end
        s= s+sold
    return (out, ind, s)
    end
end

function ind_vec_make(len::Int,loop::Int)
    if loop == 2
        indvec = collect(1:len)
        return indvec
    else
        indvec = collect(1:len)
        addvec = collect(1:len); addvec[1] = 0;
        itvec = ones(Int,len,1); itvec[1] =0;
        for n = 3:loop
            indvec = indvec + addvec;
            addvec = addvec + itvec;
        end
        return indvec
    end
end

# Function to add to θ
function addθ(θ::Array, dict::Dict{Any,Any}, data::Array, f, label::String)
    ind = length(dict) + 1
    θ = hcat(θ, f.(data))
    for n = 1:size(data,2)
        dict[ind] = label*"("*dict[n+1]*")"
    end
    return θ, dict
end

# Function to normalize the columns of θ
function θnormalize(θ)
    θnorm = zeros(size(θ))
    θnorm_vals = zeros(1,size(θ,2))
    for n = 1:1:size(θ,2)
        θnorm_vals[n] = norm(θ[:,n])
        θnorm[:,n] = θ[:,n]/θnorm_vals[n]
    end
    return θnorm, θnorm_vals
end

 #used to define the problem for the "found" problem
function reducedθ(θ::Array, coeffs::Array,dict::Dict{Any,Any})
    nzc = []
    for n = 1:size(coeffs,2)
        nzc = vcat(nzc,findall(!iszero,coeffs[:,n]))
    end
    inds = sort(unique(nzc))
    newdict =Dict()
    [newdict[i] = dict[inds[i]] for i = 1:length(inds)]
    return reducedθ = θ[:,inds], coeffs[inds,:], newdict
end
# Experimental convert the dictionary into something more human readable will not work for PDE!
function dict_read(dict::Dict{Any,Any},nv::Int)
    N = length(dict)
    pow = zeros(Int,nv)
    if nv == 1
        symbvec = ["x"]
    elseif nv == 2
        symbvec = ["x","y"]
    elseif nv == 3
        symbvec = ["x","y","z"]
    else
        symbvec = ["x1"]
        for n = 2:nv
            push!(symbvec,"x$n")
        end
    end
    for m2 = 1:1:N
        ind = 1
        if length(dict[m2]) > 3 && dict[m2][1:3] == "cos"
            continue
        elseif length(dict[m2]) > 3 && dict[m2][1:3] == "sin"
            continue
        end
        if nv <= 3
        for n ∈ symbvec
            pow[ind] = Int(length(findall(split(dict[m2],"") .== n)))
            ind += 1
        end
        elseif nv > 3
            for n ∈ 1:nv
            pow[ind] = Int(length(findall(split(dict[m2],"") .== "$n")))
            ind += 1
        end
        end
        dict[m2] = ""
        for i = 1:nv
            if pow[i] == 0
                dict[m2] = dict[m2]*""
            elseif pow[i] == 1
                dict[m2] = dict[m2]*symbvec[i]*" "
            elseif pow[i] > 1
                dict[m2] = dict[m2]*symbvec[i]*"^$(pow[i])"*" "
            end
        end
        if dict[m2] == ""
           dict[m2] = "1"
        end
    end
    return dict
end


###########################################
# Functions which sparsifies the dynamics #
# and finds the pred. coefficient vector  #
###########################################

function sparse_dynamics(θ::Array,Δ::Array,λ::T,n::Int;itr::Int=20) where {T <: Real}
    coeffs = θ\Δ
    for i = 1:itr
        ind = abs.(coeffs) .< λ
        coeffs[ind] .= 0
        bigind = ind.==0
        for j = 1:n
            coeffs[bigind[:,j],j] = θ[:, bigind[:,j]]\Δ[:,j]
        end
    end
    return coeffs
end

function sparse_dynamics(θ::Array,Δ::Array,λ::T,n::Int,β::S ;itr::Int=20) where {T <: Real, S<: Real}
    coeffs = (θ'*θ + 0.1*Diagonal(ones(size(θ,2))))\(θ'*Δ)
    for i = 1:itr
        ind = abs.(coeffs) .< λ
        coeffs[ind] .= 0
        bigind = ind.==0
        for j = 1:n
            coeffs[bigind[:,j],j] = (θ[:, bigind[:,j]]'*θ[:, bigind[:,j]] + β*Diagonal(ones(sum(bigind[:,j]))))\(θ[:, bigind[:,j]]'*Δ[:,j])
        end
    end
    return coeffs
end

function sparse_dynamicsSR3(θ::Array,Δ::Array,λ::T,n::Int,β::S,κ::W; w::Array = rand(size(θ,2),size(Δ,2)) , itr::Int = 10, R = proxl1!) where {T <: Real, S<: Real, W<: Real}
    coeffs = SR3(κ , θ, Δ , β; w = w, R = R)
    for i = 1:itr
        ind = abs.(coeffs) .< λ
        coeffs[ind] .= 0
        bigind = ind.==0
        for j = 1:n
            coeffs[bigind[:,j],j] = SR3(κ , θ[:, bigind[:,j]], Δ[:,j] , β; w = coeffs[bigind[:,j],j], R = R)
        end
    end
    return coeffs
end


include("SR3.jl")
############################################
# Functions to read the coefficient vector #
#       using the Dict from makeθ          #
############################################

function coeff_sign(n::T) where T<:Real
    if convert(Int,sign(n)) == -1
        return " -"
    else
        return " +"
    end
end

function coeffs_read(coeffs::Array,dict::Dict{Any,Any})
    num = 1:1:size(coeffs,1)
    dict2 = Dict(); ind = 1;
    for n = 1:size(coeffs,2)
        nzc = findall(!iszero,coeffs[:,n])
        dict2[n] = dict[n+1]*"' = "
        for m = 1:length(nzc)
            dict2[n] = dict2[n]*coeff_sign(coeffs[nzc[m],n])*" $(abs(round(coeffs[nzc[m],n],digits=3)))"*dict[nzc[m]]
        end
        println(dict2[n])
    end
end
