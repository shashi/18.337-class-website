This is the readme for ODEfinder.
Written by Alasdair Hastewell for MIT 18.337 in Fall 2018 as a 1st year graduate student in MIT's Applied Math Department.

Copyright 2018  Alasdair Hastewell

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

The package consists of four separate files:
  * dynamics_learning
  * ApproxFun_smoothing
  * wavelets_smoothing
  * example.ipynb

To load all the relevant packages and files simply run
include("ODEfinder.jl")

The csv file contains data downloaded from the paper

  * Accurate measurements of dynamics and reproducibility in small genetic networks, Julien O. Dubuis, Reba Samanta and Thomas Gregor, Molecular Systems    Biology 9: 639 (2013)

that is used for denonstration purposes only in the example notebook.


The required packages for this software are

Julia 1.0
LinearAlgebra, Statistics, SpecialFunctions 1.0
FFTW, v. 0.2.4
ApproxFun,  v.0.9.0

|-------------------|
| dynamics_learning |
|-------------------|

The standard three lines that would be used to find the dynamical system are

    (θ,dict) = makeθ(data [,data_derivs]; poly_order = 5, trig_order = 3)
    coeffs = sparse_dynamics(θ,time_deriv,0.15,1,0.1; itr = 15)
    coeffs_read(coeffs,dict)

This section is an implementation of the algorithms presented in

  * S. Brunton, J. Proctor and J. N. Kutz, Discovering governing equations from data: sparse identification of nonlinear dynamical systems arXiv:1509.03580

  * Data-driven identification of parametric partial differential equations, arXiv:1806.00732 (Rudy, Brunton & Kutz)

in Julia. Apart from sparse dynamics that has a slightly different implementation
in this package all the functions provided have about a factor of 5 speed up over
existing implementations in MATLAB.

The main functions provided are makeθ, sparse_dynamics, coeffs_read. Most other Functions
are used internally. There are also some supplementary functions that can be used to increase
the scope of the main functions: addθ, θnormalize.

  makeθ
|_______|

The role of makeθ is to construct the library of possible functions for the search algorithms.
There are two versions of makeθ, the first for ODE has one required argument and the second
for PDE takes two. Julia's multiple dispatch takes care of calling the correct function.

  ODE makeθ
    θ, dict = makeθ(data; poly_order, trig_order)

  PDE makeθ
    θ, dict = makeθ(data, data_deriv; poly_order, trig_order)

Both versions have two optional flag arguments. poly_order which dictates to what order the
polynomial terms are calculated to (i.e. poly_order = 5 calculates all mixed polynomial terms x,y,z,x^2,xy,..., xz^4, z^5 if there are three variables). trig_order dictates how mant (if any) trig functions are included in
the library (i.e. trig_order = 5 calculates all trig functions sin(x), sin(y), cos(x), cos(y),sin(2x), sin(2y),..., cos(5x),cos(5y) if there are two variables).

The data input should be an Array with elements that are a subtype of the Reals. It should have as many columns as there are variables. So if you have x,y,z it should have 3 columns. For PDE's the data at different times should be stacked so that the general shape is maintained as described above. data_deriv should have columns of the form [u_x,v_x,u_xx,v_xx, etc.]

The outputs are the library for the algorithm and a dictionary to read the solutions out at the end.

If you want to add to θ then you can use the addθ function,

  θ, dict = addθ(θ, dict, data, f, label)

which takes in the old θ and dict and adds to θ f.(data) and to the dict label*"(vars)". Label should therefore be a string of the desired outside function name (e.g. "sinh").

Sometimes if the degree to which the size of the elements in the columns varies is large then it is best to normalize the columns of θ and then run the sparse dynamics. This can be done with,

  θnorm, θnorm_vals = θnormalize(θ)

which return a normalized version of θ and and the normalization constants. The true coefficients can be found from the normalized ones by doing

  true_coeffs = norm_coeffs./θnorm_vals


    sparse_dynamics
  |_________________|


sparse_dynamics implements a sequential thresholding algorithm to find a best guess to the coefficient vector for the dynamical system and θ. The inputs are the library generated from makeθ, the time derivatives vector which should have the same number of rows as data and makeθ, reshaped as described above for PDE's and the number of columns equal to the number of variables.

No l2 penalty
coeffs = sparse_dynamics(θ,time_deriv,λ,n;itr)

with l2 penalty
coeffs = sparse_dynamics(θ,time_deriv,λ,n,β;itr)

The required inputs are,
  λ: the threshold number coefficients less than λ are set to 0
  n: the number of variables equals the number of columns is data and Δ
  β: Only needed if a l2 penalty is added, β is the wieght of the penalty (e.g + β||c||)

The optional input in,
  itr: The number of iterations towards convergence. Default is 20 and usually works well. Can be changed if desired if the algorithm has not yet converged

The output is a coeffs vector. This can then be fed into the read_coeffs function for a human readable version of the found ODE.

The other option is to use SR3 - a relaxed regularization method from

  * Peng Zheng, Travis Askham, Steven L. Brunton, J. Nathan Kutz, and Aleksandr Y. Aravkin: A Unified Framework for Sparse Relaxed Regularized Regression: SR3 arXiv:1807.05411

this is not as stable for smooth data but produces similar results to above but when the data is noisy can help to add some robustness. The possible built in penalty terms are

proxl1!   - l1 norm
proxl0!   - l0 norm
proxl2_2! - l2^2 norm
proxl2!   - l2 norm

coeffs = sparse_dynamicsSR3(θ,Δ,λ,n,β,κ; w = rand(size(θ,2),size(Δ,2)) , itr = 10, R = proxl1!)

κ is the relaxation term, β is the weight of penalty term. The other terms are as above. The optional terms are w - an initial guess for the coefficients (the convergence seems dependent on this guess the default is randomly initialized), itr is the number of coefficients and R is the penalty terms. Often a thresholding after the algorithm can be useful to remove stray small terms.

    coeffs_read
|_________________|

Takes in the coefficient vector and the dictionary and read outs the equation found

  coeffs_read(coeffs,dict)

The equation is printed in the terminal. There are no output variable otherwise.

|---------------------|
| ApproxFun_smoothing |
|---------------------|

This section is an implementation of the 'equi' for ApproxFun that exists in CHEBFUN for MATLAB. It follows the theory presented in:

  * M. S. Floater and K. Hormann, Barycentric rational interpolation with no poles and high rates of approximation, Numerische Mathematik 107 (2007), 315—331

The main function is the data function. The other functions in the package are demonstrated in the notebook but do not need to be used in general. For a 2D example see the examples notebook.

The standard use is,

  datafun = data(x,vals,S=Chebyshev(); order = 3, numpoints = length(x))

where x are the positions and vals are the data evaluated at vals. The standard space is Chebyshev but any ApproxFun space could be used. The optional arguments are the order of the interpolant, in theory higher order = better accuracy and the number of points to use for the interpolation to the Fun.

The ApproxFun generated can then be used to smooth and find derivatives of the data. See the example notebook.

|--------------------|
| wavelets_smoothing |
|--------------------|

This package uses the continuous wavelet transform to help smooth data. It can work better for certain types of data.

The derivative of Gaussian wavelet is defined as a type. ψ = dog_wavelet(n) produces the nth derivative of gaussian wavelet. ψ(x) evaluates ψ at the points x. ψ(w, ft = true) evaluates ψ in Fourier space.

The functions are

  cwtarray, avec = cwt(x, f,ψ,T::Float64;dj= 0.25)

which evaluates the continuous wavelet transform of f evaluated at x using the wavelet ψ, of the wavelet type. T is the x step i.e T = x(2) - x(1). The optional input dj defines the scale of the avec, smalled dj means smaller scale.

Thresholding the coefficients can help to reduce noise. Then

  icwt(x,cwt_array, avec,ψ,sig; dj = 0.25)

reconstructs the signal, where x, cwt_array,avec, ψ and sig is the original signal. If dj is changed above it needs changing here.
