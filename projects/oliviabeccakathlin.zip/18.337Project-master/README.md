# 18.337Project
Final project for 18.337 - Numerical Computing at MIT

Becca Carlson, Katharina Hoebel, Olivia Waring


package versions: 
  "HDF5"        => v"0.10.2"
  "Images"      => v"0.17.0"
  "Knet"        => v"1.1.1"
  "ImageView"   => v"0.8.1"
  
