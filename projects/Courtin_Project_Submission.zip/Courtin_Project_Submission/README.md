# 18-337-Project

#MIGP.jl

A Julia package that uses GPkit to solve Mixed-Integer Geometric Programs. 

Usage: Problems are formulated as GPkit-compatible optimization problems (see evtol.py and mico_test.py for examples). Integer varables are declared by adding "INT_" to the variable name in the docstring declaration. For example, declaring "INT_myvar" tells MIGP.jl to treat myvar as an integer variable.  

Example: 
using PyCall
@pyimport runGP

import MIGP
pkg_name = "My_Module" #Module where highest-level GP model is stored
mod_name = "My_Model" #Class name of the gp model to run.
solve_MIGP(runGP.run_GP, pkg_name, mod_name) 

The statement 'from My_Module import My_Model' should be valid. 

run_GP is a python function that does the translation between the gp model and Julia. solve_MIGP returns the optimal solution to all integer variables + continuous variables, or an error if there is no feasible integer solution. 

Currently, integer variable declarations must be in the top level model.  

**Julia Packages:** LightGraphs, TikzGraphs, TikzPictures, PyCall, JuMP, Mosek, Distributed

**Python Packages:** gpkit, gpfit, gplibrary, mosek/cvxopt

**To run the notebooks**

First, gpkit and the supporting packages must be set up on your computer. 

Installation instructions for gpkit and Mosek/cvxopt can be found here: https://gpkit.readthedocs.io/en/latest/

Clone the gpfit repo: https://github.com/convexengineering/gpfit

install using ">pip install -e gpfit"

Clone the gplibrary repo: https://github.com/convexengineering/gplibrary

install via ">pip install -e gplibrary"

Running ">python evtol.py" from the main folder should now output a solution to the model. 

Running either notebook will now work. 

This package is solver agnostic; Mosek requires a (free academic) license.  cvxopt is open source and will also work (albeit more slowly). 

gpfit and gplibrary are also required, and can be found at https://github.com/convexengineering.

