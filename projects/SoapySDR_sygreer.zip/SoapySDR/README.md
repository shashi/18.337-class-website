# SoapySDR.jl
### MIT 18.337/6.338 Fall 2018 Final project 
Sarah Greer (1st year CSE-Math PhD student, sygreer@mit.edu)

This package is available on GitHub as [SoapySDR.jl](https://github.com/sygreer/SoapySDR.jl/).

This is a Julia wrapper for [SoapySDR](https://github.com/pothosware/SoapySDR/wiki) to enable SDR processing in Julia. 
The presentation I gave in class is the Jupyter notebook at ./examples/SoapySDR.jl.ipynb, and is also available [here](https://github.com/sygreer/SoapySDR.jl/blob/master/examples/SoapySDR.jl.ipynb).


### How to use
You will need...
- an SDR dongle like an [RTL-SDR](https://www.amazon.com/RTL-SDR-Blog-RTL2832U-Software-Defined/dp/B0129EBDS2) (having an antenna helps, too)
- [SoapySDR](https://github.com/pothosware/SoapySDR/wiki) and the corresponding driver for your dongle installed on your system and in Julia's path

To use, please see the example in the Jupyter notebook. This package calls SoapySDR's C API and uses the same calls in the [SoapySDR Device](https://github.com/pothosware/SoapySDR/blob/master/include/SoapySDR/Device.h) and [other](https://github.com/pothosware/SoapySDR/tree/master/include/SoapySDR) C headers. [This](https://pothosware.github.io/SoapySDR/doxygen/latest/classSoapySDR_1_1Device.html) may also be helpful.
