using Test
include("../src/RunTests.jl")
