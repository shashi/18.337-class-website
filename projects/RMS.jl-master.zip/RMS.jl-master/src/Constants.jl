const R = 8.314 #J/(mol*K)
export R
const Na = 6.022e23 #molecules/mol
export Na
const kB = R/Na #J/(molecule*K)
export kB
