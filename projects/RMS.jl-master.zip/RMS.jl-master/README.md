# RMS - Reaction Mechanism Simulator

## Description
RMS is a Julia package for simulating and analyzing chemical reaction mechanisms.  

