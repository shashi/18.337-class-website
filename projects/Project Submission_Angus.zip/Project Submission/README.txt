This code only works on JULIA-1.0.0 and up.
The dependencies are:
LinearAlgebra
SparseArrays
Plots
ArrayFire

The input file must follow the STAP input procedure as described in http://web.mit.edu/kjb/www/Books/FEP_2nd_Edition_4th_Printing.pdf, page 988-994. The solver only reads in 3D data, but currently only solves for 2D (x,y) geometries, and ignores the z coordinates.

A sample input file called PatchTest.txt has been included, and a sample input generator called PatchTestGenerator.ipynb has also been included. Note that the Patch Test Generator's output has to be parsed by a parser which takes all "," and outputs a newline "\n" before the input file can be used.

Another sample file called PlateWithHole.txt has also been included, which shows an example of a significantly more complex geometry.

In tradmode = false, the OFE solver attempts to assign all triangular elements to be either a pure overlapping element, or a coupled overlapping element. Setting tradmode = true causes the solver to revert to being a traditional OFE solver.

verbose = true shows how the solver is parsing the input in real time. It is recommended to turn this off when 