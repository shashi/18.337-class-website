NSdiff implements methods to take LD-derivatives of Julia functions using forward mode
automatic differentiation (AD) for nonsmooth (absfactorable) functions. Unlike other AD 
packages available in Julia, NSdiff can provide useful generalized derivatives at 
nonsmooth points that can be used for nonmsooth equation solving methods such as 
semismooth or LP Newton. Detailed background on the theory of LD-derivatives and their
applications for AD can be found in "Computationally relevant generalized derivatives: 
theory, evaluation and applications," PI Barton, KA Khan, P Stechlinski, HAJ Watson
- Optimization Methods and Software, 2018.

NSdiff differentiates a function in respect to one variable, which can be scalar or 
vector-valued and is specified as a "var" type. The other function inputs are assumed
to be system parameters. The macro @nsdiff will run the Julia function using the "LDder"
object. @val and @der can be used to extract the function value and LD-derivative from the
result. And @jacobian gives a useful element of the B-subdifferential or Clarke Jacobian.
If no directions matrix is specified for @nsdiff and @jacobian, the identity matrix is
used. An example of using the code is given below:

nsVec1(x) = [abs(x[1]-x[2]);max(0,min(x[1],x[2]))]

y = var([0,0])

a = @nsdiff nsVec1(y)
@val a
@jacobian a

or

a = @nsdiff nsVec1(y) M
@val a
@jacobian a M

Julia version: 1.0.0
Required packages: LinearAlgebra