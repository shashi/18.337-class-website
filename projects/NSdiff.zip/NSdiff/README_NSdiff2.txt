NSdiff2 implements methods to take first and second order LD-derivatives of Julia
functions using forward mode automatic differentiation (AD) for nonsmooth (absfactorable)
functions. To our knowledge, no other software exists to calculate higher-order
derivatives of nonsmooth functions nor has any theory been developed to define these
derivative elements.

NSdiff2 differentiates a scalar function in respect to one variable, which can be scalar
or vector-valued and is specified as a "var" type. The other function inputs are assumed
to be system parameters. The macro @nsdiff2 will run the Julia function using the "LDder2"
object. @val and @der2 can be used to extract the function value and second-order 
LD-derivative from the result. And @gradient and @hessian give a limiting Jacobian or 
Hessian for the function. If no directions matrix is specified for @nsdiff2, @gradient,
or @hessian, the identity matrix isused. An example of using the code is given below:

nsScal(x) = mid(x[2]+1,x[2]*x[2]-2*x[2]*x[1],x[2]*x[2]-1)

y = var([-0.5,-1])

a = @nsdiff2 nsVec1(y)
@val a
@gradient a
@hessian a

or

a = @nsdiff nsVec1(y) M
@val a
@gradient a M
@hessian a M

Julia version: 1.0.0
Required packages: LinearAlgebra