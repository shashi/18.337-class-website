using Base.Cartesian
using LinearMaps
using IterativeSolvers
using Statistics

# define boundary condition types
@enum KIB_BC NoSlip=1

function no_slip(v::Array)
    return (NoSlip, 0)
end

#=
KIB_Lagrangian_Mesh contains information about a rigid object placed in the simulation box in D-d

N - the number of mesh points
U - a function that takes time and returns a D-dimensional array for linear velocity
ω - a function that takes time and returns a D-dimeionsal array for rotational velocity
=#

struct KIB_Lagrangian_Mesh{T<:AbstractFloat,D}
    N::Int
    U::Function
    ω::Function
    
    function KIB_Lagrangian_Mesh{T}(D, N, U, ω) where T
        return new{T,D}(N,U,ω)
    end
    
    function KIB_Lagrangian_Mesh(D,N,U,ω)
        return new{Float64,D}(N,U,ω)
    end
end

#= 
KIB_Grid defines the grid object and boundary conditions for the simulation in D-d

D - the dimension of the simulation
h - the Eulerian grid size
N - a tuple containing the number of cells in each direction
ϕ - the kernel function
ϕ_d - the support of the kernel function used

BC_fxns - a D-array of functions that takes a position and returns a tuple containing
    the type of BC and its value
object - a Lagrangian object contained in the grid

dt - the time step
ρ - density
μ - viscosity
Nt - number of time steps to take

=#
struct KIB_Grid{T<:AbstractFloat,D}
    D::Int
    h::T
    N::Tuple{Vararg{Int,D}}
    ϕ::Function
    ϕ_d::Int
    BC_fxns::Array{Function,1}
    object::KIB_Lagrangian_Mesh{T,D}
    Δt::T
    ρ::T
    μ::T
    Nt::Int
    
    function KIB_Grid(D, h, N, ϕ, ϕ_d, BC_fxns, object,Δt,ρ,μ,Nt)
        if length(N) > D
            error("N not consistent with number of dimensions")
        end
        
        if length(BC_fxns) != D
            error("BC_fxns must be of size D")
        end
        
        return new{typeof(h),D}(D, h, N, ϕ, ϕ_d, BC_fxns, object,Δt,ρ,μ,Nt)
    end
end

# ==================================== HELPER FUNCTIONS ====================================================

# 6-point kernel function
function ϕ(r::AbstractFloat)
    r >= 0 || error("r must be greater than 0")
    
    r >=1 || return 11/20          - 1/2*r^2           + 1/4*r^4  - 1/12*r^5
    r >=2 || return 17/40  + 5/8*r - 7/4*r^2 + 5/4*r^3 - 3/8*r^4  + 1/24*r^5
    r >=3 || return 81/40 - 27/8*r + 9/4*r^2 - 3/4*r^3 + 1/8*r^4 - 1/120*r^5
    
    return 0.0
end

# converts subscript to index
function s2i(v::Tuple{Vararg{Int,D}}, N::Tuple{Vararg{Int,D}}) where D
    i = 1
    
    for k = 1:D
        i += (v[k] - 1)*prod(N[k+1:D])
    end
    
    return i
end

# converts subscript to index and add 1 to the dimension dim
function s2ip(v::Tuple{Vararg{Int,D}}, N::Tuple{Vararg{Int,D}}, dim::Int) where D
    i = 1
    
    for k = 1:D
        if k == dim
            i += (v[k])*prod(N[k+1:D])
        else
            i += (v[k] - 1)*prod(N[k+1:D])
        end
    end
    
    return i
end

# converts subscript to index and subtract 1 from the dimension dim
function s2im(v::Tuple{Vararg{Int,D}}, N::Tuple{Vararg{Int,D}}, dim::Int) where D
    i = 1
    
    for k = 1:D
        if k == dim
            i += (v[k] - 2)*prod(N[k+1:D])
        else
            i += (v[k] - 1)*prod(N[k+1:D])
        end
    end
    
    return i
end

# converts index to subscript
function i2s(i::Integer, N::Tuple{Vararg{Int,D}}) where D
    v = zeros(Int, D)
    
    left = i-1
    for k = 1:D
        a = prod(N[k+1:D])
        b = div(left, a)
        v[k] = b + 1
        left -= b*a
    end
    
    return ntuple(i -> v[i], D)
end

function get_u(u::AbstractVector, s::Tuple{Vararg{Int,2}}, N::Tuple{Vararg{Int,2}}, BC_fxn::Function, h::AbstractFloat)
    
    # inside box
    if all(s .>= 1) && all(s .<= N)
        return u[s2i(s,N)]
    end

    # outside box
    bdry_s = ntuple(i -> min(max(1,s[i]), N[i]), 2)
    BC_type::KIB_BC, val::AbstractFloat = BC_fxn([-h/2 + bdry_s[i]*h for i in 1:2])
    
    if any(s .== 0) || any(s .== (N .+ 1))
        BC_type == NoSlip && return 0.0
    else
        news1 = s[1]
        news2 = s[2]
        
        if s[1] < 0
            news1 = -s[1]
        end
        if s[1] > (N[1]+1)
            news1 = N[1] + 1 - (s[1] - N[1] - 1)
        end
        if s[2] < 0
            news2 = -s[2]
        end
        if s[2] > (N[2]+1)
            news2 = N[2] + 1 - (s[2] - N[2] - 1)
        end
        
        news = (news1, news2)
        
        BC_type == NoSlip && return -u[s2i(news,N)]
    end
end

# =========================================== OPERATORS =========================================

#=
calculate the centered difference laplacian for a velocity vector and store the result in res

grid - the Eulerian grid object
dim - the dimension of the velocity vector (i.e., 1 for u_x and 2 for u_y)
    this is needed to choose the right BC  fxn
=#
function laplacian_u(u::AbstractVector, res::AbstractVector, grid::KIB_Grid{T,2}, dim::Int) where T
    
    for i = 1:length(u)
        
        s = i2s(i, grid.N) # subscript for current velocity
        
        left = (s[1]-1,s[2])
        right = (s[1]+1,s[2])
        top = (s[1],s[2]+1)
        down = (s[1],s[2]-1)
        
        # compute laplacian
        l = get_u(u, left, grid.N, grid.BC_fxns[dim], grid.h)
        l += get_u(u, right, grid.N, grid.BC_fxns[dim], grid.h)
        l += get_u(u, top, grid.N, grid.BC_fxns[dim], grid.h)
        l += get_u(u, down, grid.N, grid.BC_fxns[dim], grid.h)
        l -= 4*u[i]
        
        res[i] = l / grid.h^2
    end
    
end

#=
calculates the directional derivative of the pressure vector and stores the result in res

grid - the Eulerian grid object
diffdim - the dimension of the directional derivative (i.e., 1 for x and 2 for y)
=#
function central_diff_p(p::AbstractVector, res::AbstractVector, grid::KIB_Grid{T,2}, diffdim::Int) where T
    
    for i = 1:length(p)
        
        s = i2s(i, grid.N)
        left = ntuple(k -> s[k] - (k==diffdim), 2)
        
        leftp = 0.0
        
        if left[diffdim] != 0
            leftp = p[s2i(left,grid.N)]
        end
        
        res[i] = (p[i] - leftp) / grid.h
            
    end
end

#=
calculate the divergence of the velocity field (at the centered grid points)

u1 and u2 - the difference components of velocity
grid - the Eulerian grid object
dim - the dimension of the velocity vector (i.e., 1 for u_x and 2 for u_y)
    this is needed to choose the right BC  fxn
=#
function div_u(u1::AbstractVector, u2::AbstractVector, res::AbstractVector, grid::KIB_Grid{T,2}) where T
    
    for i = 1:length(u1)
        
        s = i2s(i, grid.N) # subscript for current velocity
        
        right = (s[1]+1,s[2])
        top = (s[1],s[2]+1)
        
        # compute the divergence
        dv = get_u(u1, right, grid.N, grid.BC_fxns[1], grid.h) - u1[i]
        dv += get_u(u2, top, grid.N, grid.BC_fxns[2], grid.h) - u2[i]
        
        res[i] = dv / grid.h
    end
    
end

#=
calculates a linearization of the nonlinear advection term in the NS equations for use with Picard iteration

oldu1 and oldu2 - previous iterations of velocity for Picard iteration
u1 and u2 - current velocities in the x and y directions
res1 and res2 - the results of the advection term in both directions
grid - the Eulerian grid object
=#
function advect(oldu1::AbstractVector, oldu2::AbstractVector, u1::AbstractVector, u2::AbstractVector,
        res1::AbstractVector, res2::AbstractVector, grid::KIB_Grid{T,2}) where T
    
    for i = 1:length(u1)
        
        s = i2s(i, grid.N) # subscript for current velocity
        
        # for u1
        left_u1 = get_u(u1, (s[1]-1,s[2]), grid.N, grid.BC_fxns[1], grid.h)
        right_u1 = get_u(u1, (s[1]+1,s[2]), grid.N, grid.BC_fxns[1], grid.h)
        top_u1 = get_u(u1, (s[1],s[2]+1), grid.N, grid.BC_fxns[1], grid.h)
        down_u1 = get_u(u1, (s[1],s[2]-1), grid.N, grid.BC_fxns[1], grid.h)
        
        u2_avg1 = get_u(oldu2, (s[1]-1,s[2]), grid.N, grid.BC_fxns[2], grid.h)
        u2_avg2 = get_u(oldu2, (s[1]-1,s[2]+1), grid.N, grid.BC_fxns[2], grid.h)
        u2_avg3 = get_u(oldu2, (s[1],s[2]), grid.N, grid.BC_fxns[2], grid.h)
        u2_avg4 = get_u(oldu2, (s[1],s[2]+1), grid.N, grid.BC_fxns[2], grid.h)
        
        old_u2_avg = (u2_avg1 + u2_avg2 + u2_avg3 + u2_avg4) / 4.0
        
        grad_u1_1 = (right_u1 - left_u1)/(2*grid.h)
        grad_u1_2 = (top_u1 - down_u1)/(2*grid.h)
        
        # for u2
        left_u2 = get_u(u2, (s[1]-1,s[2]), grid.N, grid.BC_fxns[1], grid.h)
        right_u2 = get_u(u2, (s[1]+1,s[2]), grid.N, grid.BC_fxns[1], grid.h)
        top_u2 = get_u(u2, (s[1],s[2]+1), grid.N, grid.BC_fxns[2], grid.h)
        down_u2 = get_u(u2, (s[1],s[2]-1), grid.N, grid.BC_fxns[2], grid.h)
        
        u1_avg1 = get_u(oldu1, (s[1],s[2]-1), grid.N, grid.BC_fxns[1], grid.h)
        u1_avg2 = get_u(oldu1, (s[1]+1,s[2]-1), grid.N, grid.BC_fxns[1], grid.h)
        u1_avg3 = get_u(oldu1, (s[1],s[2]), grid.N, grid.BC_fxns[1], grid.h)
        u1_avg4 = get_u(oldu1, (s[1]+1,s[2]), grid.N, grid.BC_fxns[1], grid.h)
        
        old_u1_avg = (u1_avg1 + u1_avg2 + u1_avg3 + u1_avg4) / 4.0
        
        grad_u2_1 = (right_u2 - left_u2)/(2*grid.h)
        grad_u2_2 = (top_u2 - down_u2)/(2*grid.h)
        
        # compute the divergence
        n1 = oldu1[i]*grad_u1_1 + old_u2_avg*grad_u1_2
        n2 = old_u1_avg*grad_u2_1 + oldu2[i]*grad_u1_2
        
        res1[i] = n1
        res2[i] = n2
    end
    
end

#=
spreads forces or velocities from the Eulerian to the Lagrangian grid

v1 and v2 - two components of a face-centered vector field
X1 and X2 - the two coordinates for the positions of the Lagrangian markers
lag_mesh - the Lagrangian mesh object
t - the time
=#
function eul_to_lag(v1::AbstractVector, v2::AbstractVector, res1::AbstractVector, res2::AbstractVector,
        X1::AbstractVector, X2::AbstractVector, lag_mesh::KIB_Lagrangian_Mesh{T,2}, grid::KIB_Grid{T,2}) where T
    
    for i = 1:lag_mesh.N
        
        x1 = X1[i]
        x2 = X2[i]
        
        min1 = Int(ceil(x1/grid.h + 1 - grid.ϕ_d))
        max1 = Int(floor(x1/grid.h + 1 + grid.ϕ_d))
        min2 = Int(ceil(x2/grid.h + 1 - grid.ϕ_d))
        max2 = Int(floor(x2/grid.h + 1 + grid.ϕ_d))
        
        accum1 = 0.0
        accum2 = 0.0
        
        # accumulate for each Lagrangian point
        for j = min1:max1
            for k = min2:max2
                
                val1 = get_u(v1, (j,k), grid.N, grid.BC_fxns[1], grid.h)
                val2 = get_u(v2, (j,k), grid.N, grid.BC_fxns[1], grid.h)
                
                accum1 += val1*grid.ϕ(abs(x1/grid.h - (j-1)))*grid.ϕ(abs(x2/grid.h - (k-0.5)))
                accum2 += val2*grid.ϕ(abs(x1/grid.h - (j-0.5)))*grid.ϕ(abs(x2/grid.h - (k-1)))
            end
        end
        
        res1[i] = accum1
        res2[i] = accum2
    end
    
end

#=
spreads forces or velocities from the Lagrangian to the Eulerian grid

v1 and v2 - two components of a vector field on the Lagrangian mesh
X1 and X2 - the two coordinates for the positions of the Lagrangian markers
lag_mesh - the Lagrangian mesh object
t - the time
=#
function lag_to_eul(v1::AbstractVector, v2::AbstractVector, res1::AbstractVector, res2::AbstractVector,
        X1::AbstractVector, X2::AbstractVector, lag_mesh::KIB_Lagrangian_Mesh{T,2}, grid::KIB_Grid{T,2}) where T
    
    res1 .= 0.0
    res2 .= 0
    
    for i = 1:lag_mesh.N
        
        x1 = X1[i]
        x2 = X2[i]
        
        min1 = Int(ceil(x1/grid.h + 1 - grid.ϕ_d))
        max1 = Int(floor(x1/grid.h + 1 + grid.ϕ_d))
        min2 = Int(ceil(x2/grid.h + 1 - grid.ϕ_d))
        max2 = Int(floor(x2/grid.h + 1 + grid.ϕ_d))
        
        # constrain to be within the grid since we don't need to spread to ghost cells
        min1 = max(min1,1)
        max1 = min(max1,grid.N[1])
        min2 = max(min2,1)
        max2 = min(max2,grid.N[2])
        
        # spread to Eulerian grid
        for j = min1:max1
            for k = min2:max2
                
                res1[s2i((j,k),grid.N)] += v1[i]*grid.ϕ(abs(x1/grid.h - (j-1)))*grid.ϕ(abs(x2/grid.h - (k-0.5)))
                res2[s2i((j,k),grid.N)] += v2[i]*grid.ϕ(abs(x1/grid.h - (j-0.5)))*grid.ϕ(abs(x2/grid.h - (k-1)))
                
            end
        end
    end
    
end

# ========================================== INTEGRATOR ===================================================

#=
The main integration function for simulating fluid flow in time

u1_0 - initial x velocity
u2_0 - initial y velocity
X1_0 - initial Lagrangian mesh x coordinates
X2_0 - initial Lagrangian mesh y coordinates
grid - a KIB_Grid object that specifies the Eulerian grid and other integration constants
=#
function integrate(u1_0::AbstractVector, u2_0::AbstractVector, X1_0::AbstractVector, X2_0::AbstractVector,
    grid::KIB_Grid{T,2}) where T
    
    sz = prod(grid.N)
    lag_size = grid.object.N
    Nt = grid.Nt
    Δt = grid.Δt
    ρ = grid.ρ
    μ = grid.μ
    
    Ts = convert(Array, LinRange(0, Nt*Δt, Nt+1))
    
    U1 = zeros(sz, Nt+1)
    U2 = zeros(sz, Nt+1)
    P = zeros(sz, Nt+1)
    X1 = zeros(lag_size, Nt+1)
    X2 = zeros(lag_size, Nt+1)
    
    # initialize
    @views U1[:,1] .= u1_0
    @views U2[:,1] .= u2_0
    @views X1[:,1] .= X1_0
    @views X2[:,1] .= X2_0
    
    rhs = zeros(3*sz + 2*lag_size)
    
    tmpsz = zeros(sz)
    tmpsz2 = zeros(sz)
    tmplag = zeros(lag_size)
    tmplag2 = zeros(lag_size)
    
    prevu1 = zeros(sz)
    prevu2 = zeros(sz)
    
    newsol = vcat(u1_0, u2_0, zeros(sz), zeros(2*lag_size))
    
    # main time loop
    for i = 2:Nt+1
        
        t = (i-1)*Δt
        
        # ---------- set right-hand side -------------------
        rhs .= 0.0
        @views rhs[1:sz] .= ρ/Δt .* U1[:,i-1]
        @views rhs[sz+1:2*sz] .= ρ/Δt .* U2[:,i-1]
        
        # calculate linear and angular velocities from center of mass
        @views com1 = mean(X1[:,i-1])
        @views com2 = mean(X2[:,i-1])
        
        @views rhs[3*sz+1:3*sz+lag_size] .= grid.object.U(t)[1]
        @views rhs[3*sz+lag_size+1:end] .= grid.object.U(t)[2]
        
        ω = grid.object.ω(t)
        θ = ω*Δt
        cθ = cos(θ)
        sθ = sin(θ)
        
        # calculate velocity based on a rotation around the center of mass
        @views rhs[3*sz+1:3*sz+lag_size] .+= ((X1[:,i-1] .- com1).*cθ - (X2[:,i-1] .- com2).*sθ .- X1[:,i-1] .+ com1)/Δt
        @views rhs[3*sz+lag_size+1:end] .+= ((X1[:,i-1] .- com1).*sθ + (X2[:,i-1] .- com2).*cθ .- X2[:,i-1] .+ com2)/Δt
        
        @views X1[:,i] = X1[:,i-1] + rhs[3*sz+1:3*sz+lag_size].*Δt
        @views X2[:,i] = X2[:,i-1] + rhs[3*sz+lag_size+1:end].*Δt
        
        @views prevu1 .= U1[:,i-1]
        @views prevu2 .= U2[:,i-1]
        
        # ---------- construct linear map --------------------
        
        
        func_map(y::AbstractVector, x::AbstractVector) = begin
            # first row
            @views y[1:sz] .= ρ/Δt .* x[1:sz]
            @views y[sz+1:2*sz] .= ρ/Δt .* x[sz+1:2*sz]
            
            @views advect(prevu1, prevu2, x[1:sz], x[sz+1:2*sz], tmpsz, tmpsz2, grid)
            @views y[1:sz] .+= ρ .* tmpsz
            @views y[sz+1:2*sz] .+= ρ .* tmpsz2
            
            @views central_diff_p(x[2*sz+1:3*sz], tmpsz, grid, 1)
            @views central_diff_p(x[2*sz+1:3*sz], tmpsz2, grid, 2)
            @views y[1:sz] .+=  tmpsz
            @views y[sz+1:2*sz] .+= tmpsz2
            
            @views laplacian_u(x[1:sz], tmpsz, grid, 1)
            @views laplacian_u(x[sz+1:2*sz], tmpsz2, grid, 2)
            @views y[1:sz] .-=  μ .* tmpsz
            @views y[sz+1:2*sz] .-= μ .* tmpsz2
            
            @views lag_to_eul(x[3*sz+1:3*sz+lag_size], x[3*sz+lag_size+1:end], tmpsz, tmpsz2,
                X1[:,i-1], X2[:,i-1], grid.object, grid)
            @views y[1:sz] .-=  tmpsz
            @views y[sz+1:2*sz] .-=  tmpsz2
            
            # second row
            @views div_u(x[1:sz], x[sz+1:2*sz], tmpsz, grid)
            @views y[2*sz+1:3*sz] .= tmpsz
            
            # third row
            @views eul_to_lag(x[1:sz], x[sz+1:2*sz], tmplag, tmplag2, X1[:,i-1], X2[:,i-1], grid.object, grid)
            @views y[3*sz+1:3*sz+lag_size] .= tmplag
            @views y[3*sz+lag_size+1:end] .= tmplag2
        end
        
        A = LinearMap{T}(func_map,3*sz+2*lag_size,ismutating=true)
        
        # ------------- apply iterative solver --------------------------
        
        if ρ == 0.0
            idrs!(newsol, A, rhs)
        else
            # do Picard iterations
            for k = 1:5
                idrs!(newsol, A, rhs)
                
                @views prevu1 .= newsol[1:sz]
                @views prevu2 .= newsol[sz+1:2*sz]
            end
        end
        
        # ------------ record new values -----------------------------
        
        @views U1[:,i] .= newsol[1:sz]
        @views U2[:,i] .= newsol[sz+1:2*sz]
        @views P[:,i] .= newsol[2*sz+1:3*sz]
        
    end
    
#     return Ts, U1, U2, P, X1, X2
    return X1,X2,U1,U2
end
