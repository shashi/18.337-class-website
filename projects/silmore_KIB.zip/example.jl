# -----------------------------
# This example runs an immersed boundary simulation of a
# rigidly rotating square in 2D.
# ------------------------------

using Plots; pyplot()
include("KIB.jl")

#linear velocity
function U_zero(t)
    return [0.0,0.0] .* cos(t)
end

# angular velocity
function ω_zero(t)
    return 1.0
end

# create Lagrangian mesh
lag_N = 100
test_lag_mesh = KIB_Lagrangian_Mesh(2, lag_N, U_zero, ω_zero)

# create Eulerian mesh and specify parameters
h = 0.1
N = (10,10)
BC_fxns = fill(no_slip, 2)
object = test_lag_mesh

Δt = 0.001  # time step
ρ = 0.0     # density
μ = 1.0     # viscosity
Nt = 1      # number of time steps

grid = KIB_Grid(2, h, N, ϕ, 3, BC_fxns, object,Δt,ρ,μ,Nt)

# create a square object
side_sz = Int(lag_N/4)
X1 = vcat(zeros(side_sz), LinRange(0.0, 1 - 1/side_sz, side_sz), ones(side_sz), LinRange(1.0, 1/side_sz, side_sz))
X2 = vcat(LinRange(0.0, 1 - 1/side_sz, side_sz), ones(side_sz), LinRange(1.0, 1/side_sz, side_sz), zeros(side_sz))

X1 .= 0.2.*X1 .+ 0.4
X2 .= 0.2.*X2 .+ 0.4

# run simulation
resX1, resX2, resU1, resU2 = integrate(zeros(prod(N)), zeros(prod(N)), X1, X2, grid)

# plot velocities
xs = [(j-0.5)*grid.h for i=1:grid.N[1],j=1:grid.N[2]][:]
ys = [(i-0.5)*grid.h for i=1:grid.N[1],j=1:grid.N[2]][:]

quiver(xs, ys, quiver=(resU1[:,2], resU2[:,2]), lc=:Blue)

# plot object

plot!(vcat(resX1[:,2], resX1[1,2]), vcat(resX2[:,2], resX2[1,2]), lw=2, lc=:Black, aspect_ratio=:equal, label="")
xlims!(0,1)
ylims!(0,1)